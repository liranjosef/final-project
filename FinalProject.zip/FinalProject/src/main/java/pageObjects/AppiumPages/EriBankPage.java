package pageObjects.AppiumPages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;

public class EriBankPage {

    private AppiumDriver driver;

    public EriBankPage(AppiumDriver driver) {
        this.driver = driver;
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(3)), this);
    }

    @AndroidFindBy(xpath = "//*[@id='usernameTextField']")
    public WebElement userFieldElement;

    @AndroidFindBy(xpath = "//*[@id='passwordTextField']")
    public WebElement passwordFieldElement;


    @AndroidFindBy(xpath = "//*[@text='Login']")
    public WebElement loginElement;

    @AndroidFindBy(xpath = "//*[@text='Logout']")
    public WebElement logoutElement;


}
