package pageObjects.DesktopPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CalculatorPage {

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num0Button']")
    public WebElement zero;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num1Button']")
    public WebElement one;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num2Button']")
    public WebElement two;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num3Button']")
    public WebElement three;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num4Button']")
    public WebElement four;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num5Button']")
    public WebElement five;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num6Button']")
    public WebElement six;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num7Button']")
    public WebElement seven;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num8Button']")
    public WebElement eight;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='num9Button']")
    public WebElement nine;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='plusButton']")
    public WebElement add;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='minusButton']")
    public WebElement subtract;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='divideButton']")
    public WebElement divide;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='multiplyButton']")
    public WebElement multiply;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='equalButton']")
    public WebElement equal;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='clearButton']")
    public WebElement clear;

    @FindBy(how = How.XPATH, using = "//*[@AutomationId='CalculatorResults']")
    public WebElement result;


}
