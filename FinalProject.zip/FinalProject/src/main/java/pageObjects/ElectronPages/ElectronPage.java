package pageObjects.ElectronPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ElectronPage {

    @FindBy(id = "button-windows")
    public WebElement windowButtonElement;

    @FindBy(id = "button-crash-hang")
    public WebElement crashButtonElement;

    @FindBy(id = "button-menus")
    public WebElement menusButtonElement;


}
