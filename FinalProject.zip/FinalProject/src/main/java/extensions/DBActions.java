package extensions;

import utilities.CommonOps;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBActions extends CommonOps {
    static ResultSet rs;
    static Connection con;
    static Statement stmt;

    public static void initSQLConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection( getData("DB_URL"),getData("DB_USERNAME"),getData("DB_PASSWORD"));
            stmt = con.createStatement();
        }
        catch (Exception e) {
            System.out.println("Error Occurred while Connecting to DB, See Details: " + e);
        }
    }

    public static List<String> getCredentials() {
        List<String> credentials = new ArrayList<String>();
        try {
            rs= stmt.executeQuery("SELECT name,password FROM Employees WHERE comments='false'");
            //rs= stmt.executeQuery("SELECT user_name,password FROM myUsers WHERE id='1'");
            rs.next();
            credentials.add(rs.getString(1));
            credentials.add(rs.getString(2));
        }
        catch(SQLException e) {
            System.out.println("Error Occured While Printing Table Data, See Details: " + e);
        }
        return credentials;
    }

    public static void closeDBCon() {
        try {
            con.close();
        }
        catch(SQLException e) {
            System.out.println("Error Occured While Closing JDBC, See Details: " + e);
        }
    }
}
