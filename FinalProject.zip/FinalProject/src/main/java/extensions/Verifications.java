package extensions;

import io.qameta.allure.Step;
import org.testng.Assert;

public class Verifications {
    @Step("Verify String")
    public static void verifyStrings(String actual, String expected) {
        Assert.assertEquals(actual, expected);
    }
    @Step("Verify String")
    public static void verifyNumbers(int actual, int expected) {
        Assert.assertEquals(actual, expected);
    }

}
