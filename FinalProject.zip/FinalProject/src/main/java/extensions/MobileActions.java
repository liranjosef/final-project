package extensions;

public class MobileActions extends UIActions {

    //ADD SWIPE FUNCTION
    //ADD LONG PRESS FUNCTION
    //etc...

}
