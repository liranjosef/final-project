package extensions;

import io.qameta.allure.Step;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import utilities.CommonOps;

public class UIActions extends CommonOps {
    @Step("Clicking on Element")
    public static void click(WebElement elem) {
        elem.click();
    }

    @Step("Updating Text")
    public static void updateText(WebElement elem, String text) {
        elem.sendKeys(text);
    }


    @Step("Getting Element Content")
    public static String getContent(WebElement elem) {
        if (elem.getTagName().equals("input")) {
            return elem.getAttribute("value");
        } else {
            return elem.getText();
        }
    }

    @Step("Select from dropdown using index")
    public static void selectByIndex(WebElement selectorElement, int index) {
        Select mySelector = new Select(selectorElement);
        mySelector.selectByIndex(index);
    }

    @Step("Get Alert Text")
    public static String getAlertText() {
        Alert myAlert = driver.switchTo().alert();
        String alertText = myAlert.getText();
        myAlert.accept();
        return alertText;
    }






}
